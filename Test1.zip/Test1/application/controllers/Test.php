<?php defined('BASEPATH') OR exit('No direct script access allowed');
 
class Test extends CI_Controller
{
	
	 public function __construct()
    {
        parent::__construct();
        $this->load->Model('Test_model');
    }
 


 //student list page
	  public function index(){
 
 
		 $data['student_list'] = $this->Test_model->student_list(); 
		
		 $this->load->view('studentlist',$data ) ;
		

	  }




    //student add page
	  
 function add_student()
{

 $this->load->view('addstudent') ;
		

}

    
//student add data function

	  public function Save_Data()
	   {
		  
		    $studentname=$this->input->post('studentname');
           $dob=$this->input->post('dob');
           $doj=$this->input->post('doj');
          
         
		  
		  $data=array('STUDENT_NAME'=>$studentname ,'STUDENT_DOB'=>$dob,'STUDENT_DOJ'=>$doj);
		  $this->Test_model->save_info($data);
		  redirect('Test');
		  
       
	  }
	  
 //student single data function and edit page

 	 function student_fetch($student_id)  
      {  
           $output = array();  
           
           $data['blogedit'] = $this->Test_model->single_user($student_id);  
           
          $this->load->view('editstudent',$data);
         

      }

 
//student update data function 

      function update(){  

          $this->load->helper('date');
           if(isset($_POST["update"]))  

           {

            $this->Test_model->update_data($_POST);  
           $result =  $this->Test_model->update_data($_POST);
            if($_POST){
            $this->session->set_flashdata('success_msg', 'record updated successfully');
          }
         else{

            $this->session->set_flashdata('error', 'record fail to update');
 
            }
                
                redirect(base_url('Test'));

         
          
           }  
      }  
 

//student delete data function 

function delete($id)
   {
        $result=$this->Test_model->delete($id);
        redirect(base_url('Test'));
    }


	
	

	
}
 
?>